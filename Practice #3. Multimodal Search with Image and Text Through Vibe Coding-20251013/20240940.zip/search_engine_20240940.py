from pymilvus import connections, FieldSchema, CollectionSchema, DataType, Collection, utility
import numpy as np
import torch
from PIL import Image
from transformers import CLIPProcessor, CLIPModel
import os
import io

# CLIP model
MODEL_NAME = "openai/clip-vit-base-patch32"
device = "cuda" if torch.cuda.is_available() else "cpu"

# set Milvus/DiskANN
MILVUS_HOST = "localhost"
MILVUS_PORT = "19530"
IMAGE_DB_NAME = "image_db"
TEXT_DB_NAME = "text_db"
VECTOR_DIM = 512
TOP_K = 3 
METRIC_TYPE = "IP" # Inner Product

# set path
DATA_DIR = "data/database"
IMG_EMBEDDING_PATH = os.path.join(DATA_DIR, "img_embeddings.npy")
TXT_EMBEDDING_PATH = os.path.join(DATA_DIR, "txt_embeddings.npy")
IMG_FILE_DIR = "data/database/images"
TXT_FILE_DIR = "data/database/texts"
QUERY_IMAGE_DIR = "data/query/images"


# load the provided .npy embedding file
def load_embeddings():
    img_embeddings = np.load(IMG_EMBEDDING_PATH)
    txt_embeddings = np.load(TXT_EMBEDDING_PATH)

    return img_embeddings, txt_embeddings


# construct a vector database
def connect_milvus():
    alias = 'default'
    # check if connected milvus already
    if connections.has_connection(alias):
        try:
            utility.get_server_version() 
            return True
        except Exception:
            connections.remove_connection(alias)

    # if not connected, connect milvus
    connections.connect(alias="default", host=MILVUS_HOST, port=MILVUS_PORT)
    return True

# construct a vector database
def build_diskann_database(embeddings: np.ndarray, collection_name:str):
    if embeddings is None: return

    # if there is any collection remove them
    if utility.has_collection(collection_name):
        utility.drop_collection(collection_name)

    # set collection
    fields = [
        FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=False, description="File index ID"),
        FieldSchema(name="vector", dtype=DataType.FLOAT_VECTOR, dim=VECTOR_DIM, description="CLIP embedding vector")
    ]
    schema = CollectionSchema(fields, description=f"{collection_name} collection for multimodal search")
    collection = Collection(collection_name, schema)

    # insert data
    ids = [i for i in range(embeddings.shape[0])]
    data = [ids, embeddings.tolist()]
    collection.insert(data)
    collection.flush()

    # create DiskANN index
    index_params = {"index_type": "DISKANN",
                    "metric_type": "IP",
                    "params": {}
    }
    collection.create_index(field_name="vector", index_params=index_params)
    collection.load()

    return collection

# build milvus database
def setup_multimodal_system():
    img_embeddings, txt_embeddings = load_embeddings()

    # build database
    img_col = build_diskann_database(img_embeddings, IMAGE_DB_NAME)
    txt_col = build_diskann_database(txt_embeddings, TEXT_DB_NAME)

    return img_col, txt_col


# create query embedding
def get_text_embedding(text_query):
    # convert text to CLIP embedding
    inputs = CLIP_PROCESSOR(text=text_query, return_tensors="pt", padding=True).to(device)
    with torch.no_grad():
        # use Text Encoder
        text_features = CLIP_MODEL.get_text_features(**inputs)
    return text_features.cpu().numpy().astype(np.float32)

def get_image_embedding(image_source):
    # convert image to CLIP embedding
    if isinstance(image_source, (bytes, bytearray)):
        img = Image.open(io.BytesIO(image_source)).convert("RGB")
    else:
        img = Image.open(image_source).convert("RGB")

    inputs = CLIP_PROCESSOR(images=img, return_tensors="pt").to(device)
    with torch.no_grad():
        # use Image Encoder
        image_features = CLIP_MODEL.get_image_features(**inputs)
    return image_features.cpu().numpy().astype(np.float32)


# search with diskANN
def search_diskann(query_embedding, collection_name, collection):
    # Milvus search parameter (Inner Product)
    search_params = {
        "metric_type": METRIC_TYPE, 
        "params": {"nprobe": 10}
    }

    # query embedding: (1, 512) ...
    results = collection.search(
        data=query_embedding.tolist(), 
        anns_field="vector", 
        param=search_params, 
        limit=TOP_K, # top 3
        output_fields=["id"]
    )

    # get index
    top_indices = [hit.id for hit in results[0]] 
    return top_indices


# retrieve results
def retrieve_results(indices, is_image_result):
    file_extension = "jpg" if is_image_result else "txt"
    directory = IMG_FILE_DIR if is_image_result else TXT_FILE_DIR

    results = []
    for i in indices:
        filename = f"{i:06d}.{file_extension}"
        filepath = f"{directory}/{filename}"
        if is_image_result:
            results.append({
                "filepath": filepath,
                "content": None,
            })
        else:
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    content = f.read()
            except Exception as e:
                content = f"[Error reading file] {e}"

            results.append({
                "filepath": filepath,
                "content": content,
            })
    return results


# control searching
def multimodal_search(query, query_type, image_collection, text_collection):
    if query_type == "text-to-image":
        q_emb = get_text_embedding(query)
        indices = search_diskann(q_emb, IMAGE_DB_NAME, image_collection)
        result_files = retrieve_results(indices, is_image_result=True)

    elif query_type == "image-to-text":
        q_emb = get_image_embedding(query)
        indices = search_diskann(q_emb, TEXT_DB_NAME, text_collection)
        result_files = retrieve_results(indices, is_image_result=False)

    return result_files


# load CLIP model and processor
CLIP_MODEL = CLIPModel.from_pretrained(MODEL_NAME).to(device)
CLIP_PROCESSOR = CLIPProcessor.from_pretrained(MODEL_NAME)

print("start demo web")