import streamlit as st
import os
import io
from search_engine_20240940 import (
    setup_multimodal_system, multimodal_search, connect_milvus, TOP_K
)

@st.cache_resource
def setup_system_cached():
    if not connect_milvus():
        st.error("fail to connect Milvus server.")
        return None, None

    return setup_multimodal_system() 

def display_top_3_results(results, is_image):
    st.subheader(f"Top {TOP_K} Related Results:")

    if is_image:
        cols = st.columns(TOP_K)
        for i, res in enumerate(results):
            with cols[i]:
                try:
                    res_path = res.get('filepath')
                    if res_path and os.path.exists(res_path):
                        st.image(res_path, caption=os.path.basename(res_path))
                    else:
                        st.error(f"cannot find the file: {os.path.basename(res_path)}")
                except Exception:
                    st.error(f"error to visualize: {res.get('filepath')}")
    else:
        for res in results:
            filepath = res.get('filepath', 'Unknown File')
            content = res.get('content', 'Error: Content not loaded.')
            st.code(content, language='text')



def main():
    st.set_page_config(page_title="Multimodal Retrieval System", layout="wide")
    st.title("🔍Cross-Model Search with CLIP & Milvus DiskANN")
    st.caption("Search across images and texts using multimodel embeddings")

    if not connect_milvus():
        st.stop()

    IMG_COLLECTION, TXT_COLLECTION = setup_system_cached()

    if IMG_COLLECTION is None or TXT_COLLECTION is None:
        st.error("fail to connect Milvus server.")
        st.stop()

    st.sidebar.success("system ready.")


    tab1, tab2 = st.tabs(["image -> text", "text -> image"])

    with tab1:
        st.markdown("**Image-to-Text Search**")
        uploaded_file = st.file_uploader("upload an image:", type=["jpg", "jpeg", "png"], key="user_image_query")

        if uploaded_file is not None:
            st.image(uploaded_file, caption="uploaded image", width=200)
            if st.button("search for texts", key="search_text_btn"):
                results = multimodal_search(uploaded_file.read(), "image-to-text", IMG_COLLECTION, TXT_COLLECTION)
                display_top_3_results(results, is_image=False)

    with tab2:
        st.markdown("**Text-to-Image Search**")
        text_query = st.text_input("type text:", "", key="user_text_query")
        if st.button("search for images", key="search_image_btn"):
            results = multimodal_search(text_query, "text-to-image", IMG_COLLECTION, TXT_COLLECTION)
            display_top_3_results(results, is_image=True)


if __name__ == "__main__":
    main()